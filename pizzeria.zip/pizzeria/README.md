# FORNO — Pizza & More

Przykładowa, responsywna strona pizzerii wykonana w HTML, CSS i czystym JavaScript.

## Uruchomienie
Otwórz `pizzeria.html` w przeglądarce. Nie wymaga instalowania zależności ani serwera.

## Funkcje
- Responsywny układ na komputerach i telefonach
- Menu z filtrowaniem kategorii
- Koszyk z dodawaniem/usuwaniem produktów i podsumowaniem ceny
- Mobilna nawigacja
- Sekcje: hero, menu, historia, CTA i kontakt


To projekt demonstracyjny do portfolio. Koszyk nie wysyła prawdziwych zamówień.
